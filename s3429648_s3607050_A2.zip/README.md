README
COSC1254 Programming Using C++ Assignment 2

AUTHORS
Pacific Thai - s3429648
Rei Ito - s3607050

CONTRIBUTORS
Paul Miller (Start up)

FILES
Makefile
src/(*.cpp, *.h)
obj/(*.o, *.d)

INSTALL
- make
- ./draughts

BUGS
- Non known at this time
